package com.example.api_cep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCepApplicationTests {

	@Test
	void contextLoads() {
	}

}
